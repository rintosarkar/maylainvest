-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 09, 2014 at 10:29 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `maylainvest`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `AccountName` varchar(20) NOT NULL,
  `AccountNo` varchar(30) NOT NULL,
  `BankName` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `AccountName`, `AccountNo`, `BankName`) VALUES
(1, 'asds', '432354', 'retty'),
(2, 'fgnnmhx', 'etertert', 'fghf'),
(3, 'Sumaya', '786', 'dhaka bank'),
(4, 'Ananya', '786', 'dhaka bank'),
(5, 'fgnnmhx', 'etertert', 'fghf'),
(6, 'fgnnmhx', 'etertert', 'fghfssss'),
(7, 'sfesd', 'dsfsd', 'sdfsd');

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE IF NOT EXISTS `application` (
  `aid` int(20) NOT NULL AUTO_INCREMENT,
  `language` varchar(20) NOT NULL,
  `AccountName` varchar(30) NOT NULL,
  `AccountNo` varchar(20) NOT NULL,
  `BankName` varchar(30) NOT NULL,
  `Title` varchar(6) NOT NULL,
  `FirstName` varchar(15) NOT NULL,
  `MiddleName` varchar(15) NOT NULL,
  `LastName` varchar(15) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `MotherName` varchar(30) NOT NULL,
  `FatherName` varchar(30) NOT NULL,
  `DateofBirth` varchar(10) NOT NULL,
  `NIC` varchar(24) NOT NULL,
  `Nationality` varchar(35) NOT NULL,
  `NationalityBy` varchar(15) NOT NULL,
  `PermanentAddress` varchar(60) NOT NULL,
  `fPostalCode` varchar(15) NOT NULL,
  `PresentAddress` varchar(60) NOT NULL,
  `PostalCode` varchar(15) NOT NULL,
  `WorkAddress` varchar(50) NOT NULL,
  `CellNumber` varchar(15) NOT NULL,
  `WorkPhoneNo` varchar(15) NOT NULL,
  `EmailID` varchar(30) NOT NULL,
  `pEmployerName` varchar(40) NOT NULL,
  `pEmployerAddress` varchar(60) NOT NULL,
  `pPostalCode` varchar(15) NOT NULL,
  `pOccupation` varchar(15) NOT NULL,
  `pDepartment` varchar(20) NOT NULL,
  `pMonthlyIncome` varchar(10) NOT NULL,
  `TypeOfProperty` varchar(50) NOT NULL,
  `SituatedOfProperty` varchar(64) NOT NULL,
  `ValueOfProperty` varchar(50) NOT NULL,
  `KinTitle` varchar(6) NOT NULL,
  `KinFirstName` varchar(15) NOT NULL,
  `KinMiddleName` varchar(15) NOT NULL,
  `KinLastName` varchar(15) NOT NULL,
  `KinRelationship` varchar(20) NOT NULL,
  `KinPhoneHome` varchar(15) NOT NULL,
  `KinPhoneWork` varchar(15) NOT NULL,
  `KinCellNumber` varchar(15) NOT NULL,
  `KinPhysicalAddress` varchar(60) NOT NULL,
  `KinPostalCode` varchar(15) NOT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`aid`, `language`, `AccountName`, `AccountNo`, `BankName`, `Title`, `FirstName`, `MiddleName`, `LastName`, `Gender`, `MotherName`, `FatherName`, `DateofBirth`, `NIC`, `Nationality`, `NationalityBy`, `PermanentAddress`, `fPostalCode`, `PresentAddress`, `PostalCode`, `WorkAddress`, `CellNumber`, `WorkPhoneNo`, `EmailID`, `pEmployerName`, `pEmployerAddress`, `pPostalCode`, `pOccupation`, `pDepartment`, `pMonthlyIncome`, `TypeOfProperty`, `SituatedOfProperty`, `ValueOfProperty`, `KinTitle`, `KinFirstName`, `KinMiddleName`, `KinLastName`, `KinRelationship`, `KinPhoneHome`, `KinPhoneWork`, `KinCellNumber`, `KinPhysicalAddress`, `KinPostalCode`) VALUES
(1, '', 'aa', 'aa', 'aa', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `bankinformation`
--

CREATE TABLE IF NOT EXISTS `bankinformation` (
  `bid` int(20) NOT NULL AUTO_INCREMENT,
  `loanAmount` varchar(15) NOT NULL,
  `loanAmountWords` varchar(100) NOT NULL,
  `loanYear` varchar(10) NOT NULL,
  `repaymentMonth` varchar(15) NOT NULL,
  `monthlyRepaymentAmount` varchar(15) NOT NULL,
  `loanPurpose` varchar(110) NOT NULL,
  `accountName` varchar(30) NOT NULL,
  `accountNo` varchar(20) NOT NULL,
  `bankName` varchar(30) NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `bankinformation`
--

INSERT INTO `bankinformation` (`bid`, `loanAmount`, `loanAmountWords`, `loanYear`, `repaymentMonth`, `monthlyRepaymentAmount`, `loanPurpose`, `accountName`, `accountNo`, `bankName`) VALUES
(1, '85000', 'Eighty', '4', '48', '2408.3333333333', 'r', 'r', 'r', 'r'),
(2, '20000', 'Twenty', '2', '24', '983.33333333333', 'gdf', 'fdg', 'dfgdf', 'dfgdf'),
(3, '15000', 'Fifteen', '2', '24', '737.5', 'gdf', 'fdg', 'dfgdf', 'dfgdf'),
(4, '15000', '', '2', '24', '737.5', 'gdf', 'fdg', 'dfgdf', 'dfgdf'),
(5, '90000', 'Ninety', '3', '36', '3175', 'gff', 'g', 'fg', 'g'),
(6, '85000', 'Eighty', '3', '36', '2998.6111111111', 'gff', 'g', 'fg', 'g'),
(7, '15000', 'Fifteen', '2', '24', '737.5', 'qqq', 'qq', 'qq', 'qq'),
(8, '100000', 'Hundred', '19', '228', '1188.5964912280', 'z', 'z', 'z', 'z'),
(9, '90000', 'Ninety', '14', '168', '1210.7142857142', 'ds', 'x', 'x', 'x');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `uid` int(15) NOT NULL AUTO_INCREMENT,
  `uname` varchar(100) NOT NULL,
  `ucomment` varchar(500) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`uid`, `uname`, `ucomment`, `created`) VALUES
(1, 'Monirul', 'Now busy ', '2014-11-01 22:10:35'),
(2, 'Monirul', 'Chagol', '2014-11-04 11:18:19'),
(3, 'R', 's', '2014-11-06 06:07:58'),
(4, 'fff', 'ss', '2014-11-06 06:12:22'),
(5, 'fff', 'ss', '2014-11-06 06:17:48'),
(6, 'Hijab', 'Valona', '2014-11-06 06:19:38'),
(7, 'sfsfs', 'sfsdf', '2014-11-06 06:28:51'),
(8, 'Habib', 'Mia', '2014-11-06 06:46:20');

-- --------------------------------------------------------

--
-- Table structure for table `dollar`
--

CREATE TABLE IF NOT EXISTS `dollar` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `usDollar` varchar(20) NOT NULL,
  `dEn` varchar(100) NOT NULL,
  `dFr` varchar(100) NOT NULL,
  `dSp` varchar(100) NOT NULL,
  `dDe` varchar(100) NOT NULL,
  `dPo` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `dollar`
--

INSERT INTO `dollar` (`id`, `usDollar`, `dEn`, `dFr`, `dSp`, `dDe`, `dPo`) VALUES
(1, '10000', 'Ten thousand us dollars', 'Dix mille dollars américains', 'Diez mil estados unidos dólares', 'Zehn tausend US-Dollar', 'Dez mil dólares'),
(2, '15000', 'Fifteen thousand us dollars', 'Quinze mille dollars américains', 'Quince mil estados unidos dólares', 'Fünfzehn tausend US-Dollar', 'Quinze mil dólares'),
(3, '20000', 'Twenty thousand us dollars', 'Vingt mille dollars américains', 'Veinte mil estados unidos dólares', 'Zwanzig tausend US-Dollar', 'Vinte mil dólares'),
(4, '25000', 'Twenty five thousand us dollars', 'Vingt cinq mille dollars américains', 'Veinte cinco mil estados unidos dólares', 'Fünfundzwanzig tausend Dollar', 'Vinte e cinco mil dólares'),
(5, '30000', 'Thirty thousand us dollars', 'Trente mille dollars américains', 'Treinta mil estados unidos dólares', 'Dreißig tausend US-Dollar', 'Trinta mil dólares'),
(6, '35000', 'Thirty five thousand us dollars', 'Trente cinq mille dollars américains', 'Treinta cinco mil estados unidos dólares', 'Fünfunddreißigtausend US dollar', 'Trinta e cinco mil dólares'),
(7, '40000', 'Forty thousand us dollars', 'Quarante mille dollars américains', 'Cuarenta mil estados unidos dólares   ', 'Vierzig tausend US-Dollar', 'Quarenta mil dólares'),
(8, '45000', 'Forty five thousand us dollars', 'Quarante cinq mille dollars américains', 'Cuarenta y cinco mil estados unidos dólares ', 'Fünfundvierzig tausend US-Dollar', 'Quarenta e cinco mil dólares'),
(9, '50000', 'Fifty thousand us dollars', 'Cinquante mille dollars américains', 'Cincuenta mil estados unidos dólares', 'Fünfzig tausend US-Dollar', 'Cinquenta mil dólares'),
(10, '55000', 'Fifty five thousand us dollars', 'Cinquante cinq cents dollars américains', 'Cincuenta cinco mil estados unidos dólares', 'Fünfzig fünftausend US-Dollar', 'Cinqüenta e cinco mil dólares'),
(11, '60000', 'Sixty thousand us dollars ', 'Soixante mille dollars américains', 'Sesenta mil estados unidos dólares ', 'Sechzig tausend US-Dollar', 'Sessenta mil dólares'),
(12, '65000', 'Sixty five thousand us dollars', 'Soixante cinq mille dollars américains', 'Sesenta cinco mil estados unidos dólares ', 'Fünfundsechzig tausend US-Dollar', 'Sessenta e cinco mil dólares'),
(13, '70000', 'Seventy thousand us dollars', 'Soixante-dix mille dollars américains', 'Setenta mil estados unidos dólares ', 'Siebzig tausend US-Dollar', 'Setenta mil dólares'),
(14, '75000', 'Seventy five thousand us dollars ', 'Soixante-quinze mille dollars américains', 'Setenta y cinco mil estados unidos dólares  ', 'Siebzig fünftausend US-Dollar', 'Setenta e cinco mil dólares'),
(15, '80000', ' Eighty thousand us dollars ', 'Quatre-vingt mille dollars américains', 'Ochenta mil estados unidos dólares ', 'Achtzig tausend US-Dollar', 'Oitenta mil dólares'),
(16, '85000', 'Eighty five thousand us dollars', 'Quatre-vingt cinq mille dollars américains', 'Ochenta cinco mil estados unidos dólares', 'Achtzig fünftausend US-Dollar', 'Oitenta e cinco mil dólares'),
(17, '90000', 'Ninety thousand us dollars', 'Quatre-vingt-dix mille dollars américains', 'Noventa mil estados unidos dólares  ', 'Neunzig tausend US-Dollar', 'Noventa mil dólares'),
(18, '95000', 'Ninety five thousand us dollars', 'Quatre-vingt-dix cinq mille dollars américains', 'Noventa y cinco mil estados unidos dólares', 'Fünfundneunzig tausend US-Dollar', 'Noventa e cinco mil dólares'),
(19, '100000', 'Hundred Thousand us dollars', 'Cent mille dollars américains', 'Cien mil estados unidos dólares  ', 'Hundert tausend US-Dollar', 'Cem mil dólares'),
(20, '150000', 'Hundred fifty thousand us dollars', 'Cent cinquante mille dollars américains', 'Cien cincuenta mil estados unidos dólares', 'Hundert Fünfzig tausend US-Dollar', 'Cento e cinqüenta mil dólares'),
(21, '200000', 'Two hundred thousand us dollars', 'Deux cent mille dollars américains', 'Dos cien mil estados unidos dólares', 'Zwei hundert tausend US-Dollar', 'Duzentos mil dólares'),
(22, '250000', 'Two hundred fifty thousand us dollars', 'Deux cent cinquante mille dollars américains ', 'Doscientos cincuenta mil estados unidos dólares', 'Zwei hundert Fünfzig tausend US-Dollar', 'Duzentos e cinquenta mil dólares'),
(23, '300000', 'Three hundred thousand us dollars', 'Trois cent mille dollars américains', 'Tres cien mil estados unidos dólares', 'Drei hunderttausend US-Dollar', 'Trezentos mil dólares'),
(24, '350000', 'Three hundred fifty thousand us dollars', 'Trois cent cinquante mille dollars américains ', 'Trescientos cincuenta mil estados unidos dólares', 'Drei hundert Fünfzig tausend US-Dollar', 'Trezentos e cinquenta mil dólares'),
(25, '400000', 'Four hundred thousand us dollars', 'Quatre cent mille dollars américains', 'Cuatro cien mil estados unidos dólares', 'Vier hundert tausend US-Dollar', 'Quatrocentos mil dólares'),
(26, '450000', 'Four hundred fifty thousand us dollars', 'Quatre cent cinquante mille dollars américains', 'Cuatrocientos cincuenta mil estados unidos dólares', 'Vier hundert Fünfzig tausend US-Dollar', 'Quatrocentos e cinquenta mil dólares'),
(27, '500000', 'Five hundred thousand us dollars ', 'Cinq cent mille dollars américains', 'Cinco cien mil estados unidos dólares', 'Fünf hundert tausend US-Dollar', 'Quinhentos mil dólares'),
(28, '550000', 'Five hundred fifty thousand us dollars ', 'Cinq cent cinquante mille dollars américains', 'Quinientos cincuenta mil estados unidos dólares ', 'Fünf hundert Fünfzig tausend US-Dollar ', 'Quinhentos e cinquenta mil dólares'),
(29, '600000', 'Six hundred thousand us dollars', 'Six cent mille dollars américains', 'Seis cien mil estados unidos dólares', 'Sechs hundert tausend US-Dollar', 'Seiscentos mil dólares'),
(30, '650000', 'Six hundred fifty thousand us dollars', 'Six cent cinquante mille dollars américains', 'Seiscientos cincuenta mil estados unidos dólares', 'Sechs hundert Fünfzig tausend US-Dollar', 'Seiscentos e cinqüenta mil dólares'),
(31, '700000', 'Seven hundred thousand us dollars', 'Sept cent mille dollars américains', 'Siete cien mil estados unidos dólares', 'Sieben hundert tausend US-Dollar', 'Setecentos mil dólares'),
(32, '750000', 'Seven hundred fifty thousand us dollars', 'Sept cent cinquante mille dollars américains', 'Setecientos cincuenta mil estados unidos dólares', 'Sieben hundert Fünfzig tausend US-Dollar', 'Setecentos e cinquenta mil dólares'),
(33, '800000', 'Eight hundred thousand us dollars', 'Huit cent mille dollars américains', 'Ocho cien mil estados unidos dólares', 'Acht hundert  tausend US-Dollar', 'Oitocentos mil dólares'),
(34, '850000', 'Eight hundred fifty thousand us dollars', 'Huit cent cinquante mille dollars américains', 'Ochocientos cincuenta mil estados unidos dólares', 'Acht hundert Fünfzig tausend US-Dollar', 'Oitocentos e cinqüenta mil dólares'),
(35, '900000', 'Nine hundred thousand us dollars', 'Neuf cent mille dollars américains', 'Nueve cien mil estados unidos dólares', 'Neun hundert tausend US-Dollar', 'Novecentos mil dólares'),
(36, '950000', 'Nine hundred fifty thousand us dollars', 'Neuf cent cinquante mille dollars américains', 'Novecientos cincuenta mil estados unidos dólares', 'Neun hundert Fünfzig tausend US-Dollar', 'Novecentos e cinqüenta mil dólares'),
(37, '1000000', 'Ten hundred thousand us dollars ', 'Dix cent mille dollars américains', 'Diez cien mil estados unidos dólares', 'Zehn hundert tausend US-Dollar', 'Dez mil dólares');

-- --------------------------------------------------------

--
-- Table structure for table `familyinformation`
--

CREATE TABLE IF NOT EXISTS `familyinformation` (
  `fid` int(20) NOT NULL AUTO_INCREMENT,
  `fMarriedIn` varchar(100) NOT NULL,
  `fTraditional` varchar(100) NOT NULL,
  `fMarriedOut` varchar(100) NOT NULL,
  `fSingle` varchar(100) NOT NULL,
  `fSpouseTitle` varchar(6) NOT NULL,
  `fSpouseFirstName` varchar(15) NOT NULL,
  `fSpouseMiddleName` varchar(15) NOT NULL,
  `fSpouseLastName` varchar(15) NOT NULL,
  `fSpousePhysicalAddress` varchar(60) NOT NULL,
  `fSpousePostalCode` varchar(15) NOT NULL,
  `fSpousePhoneHome` varchar(15) NOT NULL,
  `fSpousePhoneWork` varchar(15) NOT NULL,
  `fSpouseCellNumber` varchar(15) NOT NULL,
  `fKinTitle` varchar(6) NOT NULL,
  `fKinFirstName` varchar(15) NOT NULL,
  `fKinMiddleName` varchar(15) NOT NULL,
  `fKinLastName` varchar(15) NOT NULL,
  `fKinRelationship` varchar(20) NOT NULL,
  `fKinPhysicalAddress` varchar(60) NOT NULL,
  `fKinPostalCode` varchar(15) NOT NULL,
  `fKinPhoneHome` varchar(15) NOT NULL,
  `fKinPhoneWork` varchar(15) NOT NULL,
  `fKinCellNumber` varchar(15) NOT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `familyinformation`
--

INSERT INTO `familyinformation` (`fid`, `fMarriedIn`, `fTraditional`, `fMarriedOut`, `fSingle`, `fSpouseTitle`, `fSpouseFirstName`, `fSpouseMiddleName`, `fSpouseLastName`, `fSpousePhysicalAddress`, `fSpousePostalCode`, `fSpousePhoneHome`, `fSpousePhoneWork`, `fSpouseCellNumber`, `fKinTitle`, `fKinFirstName`, `fKinMiddleName`, `fKinLastName`, `fKinRelationship`, `fKinPhysicalAddress`, `fKinPostalCode`, `fKinPhoneHome`, `fKinPhoneWork`, `fKinCellNumber`) VALUES
(1, 'Married In', 'Traditional', 'Married Out', 'Single', 'Mrs.', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'Mrs.', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r'),
(2, 'Married In', 'Traditional', 'Married Out', 'Single', 'Mr.', '', '', '', '', '', '', '', '', 'Mr.', '', '', '', '', '', '', '', '', ''),
(3, 'Married In', 'Traditional', 'Married Out', 'Single', 'Mr.', '', '', '', '', '', '', '', '', 'Mr.', '', '', '', '', '', '', '', '', ''),
(4, 'Married In', 'Traditional', 'Married Out', 'Single', 'Mr.', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'Mr.', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd');

-- --------------------------------------------------------

--
-- Table structure for table `maritalstatus`
--

CREATE TABLE IF NOT EXISTS `maritalstatus` (
  `mid` int(20) NOT NULL AUTO_INCREMENT,
  `mMarriedIn` varchar(10) NOT NULL,
  `mTraditional` varchar(10) NOT NULL,
  `mMarriedOut` varchar(10) NOT NULL,
  `mSingle` varchar(10) NOT NULL,
  `mTitle` varchar(6) NOT NULL,
  `mFirst Name` varchar(15) NOT NULL,
  `mMiddleName` varchar(15) NOT NULL,
  `mLastName` varchar(15) NOT NULL,
  `mPhysicalAddress` varchar(60) NOT NULL,
  `mPostalCode` varchar(15) NOT NULL,
  `mPhoneHome` varchar(15) NOT NULL,
  `mPhoneWork` varchar(15) NOT NULL,
  `mCellNumber` varchar(15) NOT NULL,
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `maritalstatus`
--


-- --------------------------------------------------------

--
-- Table structure for table `personalinformation`
--

CREATE TABLE IF NOT EXISTS `personalinformation` (
  `pid` int(20) NOT NULL AUTO_INCREMENT,
  `pTitle` varchar(6) NOT NULL,
  `pFirstName` varchar(15) NOT NULL,
  `pMiddleName` varchar(15) NOT NULL,
  `pLastName` varchar(15) NOT NULL,
  `pGender` varchar(10) NOT NULL,
  `pMotherName` varchar(30) NOT NULL,
  `pFatherName` varchar(30) NOT NULL,
  `pDateofBirth` varchar(10) NOT NULL,
  `pNIC` varchar(24) NOT NULL,
  `pNationality` varchar(35) NOT NULL,
  `pNationalityBy` varchar(15) NOT NULL,
  `pPermanentAddress` varchar(60) NOT NULL,
  `pPermanentPostalCode` varchar(15) NOT NULL,
  `pPresentAddress` varchar(60) NOT NULL,
  `pPresentPostalCode` varchar(15) NOT NULL,
  `pWorkAddress` varchar(50) NOT NULL,
  `pWorkPhoneNumber` varchar(15) NOT NULL,
  `pCellNumber` varchar(15) NOT NULL,
  `pEmailID` varchar(30) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `personalinformation`
--

INSERT INTO `personalinformation` (`pid`, `pTitle`, `pFirstName`, `pMiddleName`, `pLastName`, `pGender`, `pMotherName`, `pFatherName`, `pDateofBirth`, `pNIC`, `pNationality`, `pNationalityBy`, `pPermanentAddress`, `pPermanentPostalCode`, `pPresentAddress`, `pPresentPostalCode`, `pWorkAddress`, `pWorkPhoneNumber`, `pCellNumber`, `pEmailID`) VALUES
(1, 'Mr.', 'r', 'r', 'r', 'Male', 'r', 'r', '12/29/2014', 'r', 'Romania', 'By Birth', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r'),
(2, '0', '', '', '', '0', '', '', '', '', '0', '0', '', '', '', '', '', '', '', ''),
(3, 'Mr.', 'dd', 'dd', 'dd', 'Male', 'dd', 'dd', '12/30/2014', 'dd', 'Central African Republic', 'By Birth', 'dd', 'dd', 'dd', 'dd', 'dd', 'dd', 'dd', 'dd'),
(4, 'Mrs.', 'z', 'z', 'z', 'Other', 'z', 'z', '12/29/2014', 'z', 'Albania', 'By Birth', 'z', 'z', 'z', 'z', 'z', 'z', 'zz', 'z'),
(5, 'Mrs.', 'z', 'z', 'z', 'Other', 'z', 'z', '12/29/2014', 'z', 'Albania', 'By Birth', 'z', 'z', 'z', 'z', 'z', 'z', 'zz', 'z'),
(6, '0', '', '', '', '0', '', '', '', '', '0', '0', '', '', '', '', '', '', '', ''),
(7, 'Mr.', 'x', 'x', 'x', 'Male', 'x', 'x', '12/01/2014', 'x', 'Belgium', 'By Birth', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'lfdls@dkjjf.dsdss');

-- --------------------------------------------------------

--
-- Table structure for table `professiondetails`
--

CREATE TABLE IF NOT EXISTS `professiondetails` (
  `proid` int(20) NOT NULL AUTO_INCREMENT,
  `proEmployerName` varchar(40) NOT NULL,
  `proEmployerAddress` varchar(60) NOT NULL,
  `proPostalCode` varchar(15) NOT NULL,
  `proOccupation` varchar(15) NOT NULL,
  `proDepartment` varchar(20) NOT NULL,
  `proMonthlyIncome` varchar(10) NOT NULL,
  `proTypeofProperty` varchar(50) NOT NULL,
  `proSituatedofProperty` varchar(64) NOT NULL,
  `proValueofProperty` varchar(50) NOT NULL,
  PRIMARY KEY (`proid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `professiondetails`
--

INSERT INTO `professiondetails` (`proid`, `proEmployerName`, `proEmployerAddress`, `proPostalCode`, `proOccupation`, `proDepartment`, `proMonthlyIncome`, `proTypeofProperty`, `proSituatedofProperty`, `proValueofProperty`) VALUES
(1, 'ss', 'ss', 'ss', 'ss', 'aa', 'aa', 'aa', 'aa', 'zz'),
(2, '', '', '', '', '', '', '', '', ''),
(3, '', '', '', '', '', '', '', '', ''),
(4, 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
